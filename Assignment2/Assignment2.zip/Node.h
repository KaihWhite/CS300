//
// Created by Kaih White on 10/22/2021.
//

#ifndef ASSIGNMENT2_NODE_H
#define ASSIGNMENT2_NODE_H


class Node{
public:
    char item; // character stored in node
    Node* go; // Pointer to next node
};


#endif //ASSIGNMENT2_NODE_H
