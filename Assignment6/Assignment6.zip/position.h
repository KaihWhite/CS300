#ifndef Position_H
#define Position_H

struct Position
{
    int indexInTable = -1; //position in the table.
    int indexInBin = -1;   // position in the linked list.
};

#endif